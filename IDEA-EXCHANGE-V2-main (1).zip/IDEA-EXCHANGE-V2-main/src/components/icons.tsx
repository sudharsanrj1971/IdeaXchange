import { type LucideProps, Puzzle, Bot, Sparkles, User, BrainCircuit, Users, Vote, FileText, Send } from 'lucide-react'

export const Icons = {
  logo: (props: LucideProps) => (
    <Puzzle {...props} />
  ),
  bot: Bot,
  sparkles: Sparkles,
  user: User,
  idea: BrainCircuit,
  team: Users,
  vote: Vote,
  document: FileText,
  send: Send,
}
