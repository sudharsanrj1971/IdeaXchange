'use client'

import * as React from 'react'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { Icons } from '@/components/icons'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import { runGuideNewUsers, runSuggestNewFeatures, runImproveIdeaText } from '@/app/actions'

type Message = {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
}

export function AiChatbot() {
  const [open, setOpen] = React.useState(false)
  const [messages, setMessages] = React.useState<Message[]>([])
  const [input, setInput] = React.useState('')
  const [isLoading, setIsLoading] = React.useState(false)
  const { toast } = useToast()
  const scrollAreaRef = React.useRef<HTMLDivElement>(null)

  const handleOpen = async () => {
    setOpen(true)
    if (messages.length === 0) {
      setIsLoading(true)
      const result = await runGuideNewUsers()
      if (result.success) {
        setMessages([
          { id: '1', role: 'assistant', content: result.data || 'Hello! How can I help you with your ideas today?' },
        ])
      } else {
        setMessages([
          { id: '1', role: 'assistant', content: 'Hello! How can I help you today? I seem to be having some trouble with my advanced features right now.' },
        ])
        toast({
          variant: "destructive",
          title: "AI Error",
          description: result.error,
        })
      }
      setIsLoading(false)
    }
  }

  React.useEffect(() => {
    if (scrollAreaRef.current) {
        scrollAreaRef.current.scrollTo({ top: scrollAreaRef.current.scrollHeight, behavior: 'smooth' })
    }
  }, [messages])

  const handleQuickAction = async (action: 'guide' | 'suggest' | 'improve') => {
    setIsLoading(true);
    let response;
    let userMessageContent = '';
  
    if (action === 'guide') {
      userMessageContent = "How do I use this platform?";
      response = await runGuideNewUsers();
    } else {
      // For suggest and improve, we just show a prompt.
      const promptText = action === 'suggest' 
        ? "I can suggest new features for an idea. Please paste the idea description below." 
        : "I can help improve an idea's text. Please paste the text you want to improve below.";
      setMessages(prev => [...prev, {id: Date.now().toString(), role: 'assistant', content: promptText}]);
      setIsLoading(false);
      return;
    }
  
    const userMessage: Message = { id: Date.now().toString(), role: 'user', content: userMessageContent };
    setMessages(prev => [...prev, userMessage]);
  
    if (response.success && response.data) {
      const assistantMessage: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: typeof response.data === 'string' ? response.data : (response.data.suggestedFeatures || response.data.improvedText) };
      setMessages(prev => [...prev, assistantMessage]);
    } else {
      toast({
        variant: "destructive",
        title: "AI Error",
        description: response.error,
      });
    }
    setIsLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const newUserMessage: Message = { id: Date.now().toString(), role: 'user', content: input };
    setMessages(prev => [...prev, newUserMessage]);
    setInput('');
    setIsLoading(true);

    const lastAssistantMessage = messages.slice().reverse().find(m => m.role === 'assistant')?.content || '';
    let response;
    
    if (lastAssistantMessage.includes('suggest new features')) {
      response = await runSuggestNewFeatures({ ideaDescription: input });
    } else if (lastAssistantMessage.includes('improve an idea')) {
      response = await runImproveIdeaText({ ideaText: input });
    } else {
        response = await runGuideNewUsers();
    }

    if (response.success && response.data) {
      const content = typeof response.data === 'string' ? response.data : (response.data.suggestedFeatures || response.data.improvedText || '');
      const assistantMessage: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content };
      setMessages(prev => [...prev, assistantMessage]);
    } else {
      toast({
        variant: "destructive",
        title: "AI Error",
        description: response.error,
      });
      const assistantMessage: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: "Sorry, I couldn't process that. Please try again." };
      setMessages(prev => [...prev, assistantMessage]);
    }

    setIsLoading(false);
  }

  return (
    <>
      <Button
        className="fixed bottom-4 right-4 h-14 w-14 rounded-full shadow-lg"
        onClick={handleOpen}
        aria-label="Open AI Chatbot"
      >
        <Icons.bot className="h-7 w-7" />
      </Button>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent className="flex flex-col">
          <SheetHeader>
            <SheetTitle>Dudu AI</SheetTitle>
            <SheetDescription>Your personal assistant for refining ideas.</SheetDescription>
          </SheetHeader>
          <div className="flex-1 flex flex-col justify-between h-full">
            <ScrollArea className="flex-1 pr-4 -mr-4 mb-4" ref={scrollAreaRef}>
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${
                      message.role === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    <div
                      className={`max-w-xs rounded-lg px-4 py-2 ${
                        message.role === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>
                  </div>
                ))}
                 {isLoading && (
                    <div className="flex justify-start">
                         <div className="max-w-xs rounded-lg px-4 py-2 bg-muted">
                            <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 rounded-full bg-muted-foreground animate-pulse"></div>
                                <div className="w-2 h-2 rounded-full bg-muted-foreground animate-pulse [animation-delay:0.2s]"></div>
                                <div className="w-2 h-2 rounded-full bg-muted-foreground animate-pulse [animation-delay:0.4s]"></div>
                            </div>
                        </div>
                    </div>
                )}
              </div>
            </ScrollArea>
            { messages.length > 0 && !isLoading && (
            <div className='mb-2 space-y-2'>
              <p className="text-sm text-muted-foreground">What do you want to do?</p>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" onClick={() => handleQuickAction('guide')}>Guide me</Button>
                <Button variant="outline" size="sm" onClick={() => handleQuickAction('suggest')}>Suggest features</Button>
                <Button variant="outline" size="sm" onClick={() => handleQuickAction('improve')}>Improve idea text</Button>
              </div>
            </div>
            )}
            <form onSubmit={handleSubmit} className="flex items-center space-x-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask me anything..."
                disabled={isLoading}
              />
              <Button type="submit" size="icon" disabled={isLoading}>
                <Icons.send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}
