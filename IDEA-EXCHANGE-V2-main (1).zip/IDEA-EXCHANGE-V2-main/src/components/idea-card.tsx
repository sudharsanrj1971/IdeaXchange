import Link from 'next/link'
import type { Idea } from '@/lib/types'
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ArrowUp, MessageCircle } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

interface IdeaCardProps {
  idea: Idea
}

export function IdeaCard({ idea }: IdeaCardProps) {
  return (
    <Card className="flex flex-col justify-between transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl">
          <Link href={`/ideas/${idea.id}`} className="hover:underline">
            {idea.title}
          </Link>
        </CardTitle>
        <CardDescription className="line-clamp-2">{idea.shortDescription}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {idea.tags.map((tag) => (
            <Badge key={tag} variant="secondary">
              {tag}
            </Badge>
          ))}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between items-center text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <Avatar className="h-6 w-6">
            <AvatarImage src={idea.author.avatarUrl} alt={idea.author.name} />
            <AvatarFallback>{idea.author.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <span>{idea.author.name}</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <ArrowUp className="h-4 w-4" />
            <span>{idea.upvotes}</span>
          </div>
          <div className="flex items-center gap-1">
            <MessageCircle className="h-4 w-4" />
            <span>{idea.comments.length}</span>
          </div>
        </div>
      </CardFooter>
      <CardFooter className="text-xs text-muted-foreground">
          Last updated {formatDistanceToNow(new Date(idea.updatedAt), { addSuffix: true })}
      </CardFooter>
    </Card>
  )
}
