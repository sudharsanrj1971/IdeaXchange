import { config } from 'dotenv';
config();

import '@/ai/flows/improve-idea-text.ts';
import '@/ai/flows/guide-new-users.ts';
import '@/ai/flows/suggest-new-features.ts';