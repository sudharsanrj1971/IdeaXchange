'use server';

/**
 * @fileOverview AI flow to improve the text of an idea description using a chatbot.
 *
 * - improveIdeaText - A function that enhances the idea description.
 * - ImproveIdeaTextInput - The input type for the improveIdeaText function.
 * - ImproveIdeaTextOutput - The return type for the improveIdeaText function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ImproveIdeaTextInputSchema = z.object({
  ideaText: z.string().describe('The text of the idea description to improve.'),
});

export type ImproveIdeaTextInput = z.infer<typeof ImproveIdeaTextInputSchema>;

const ImproveIdeaTextOutputSchema = z.object({
  improvedText: z.string().describe('The improved text of the idea description.'),
});

export type ImproveIdeaTextOutput = z.infer<typeof ImproveIdeaTextOutputSchema>;

export async function improveIdeaText(input: ImproveIdeaTextInput): Promise<ImproveIdeaTextOutput> {
  return improveIdeaTextFlow(input);
}

const improveIdeaTextPrompt = ai.definePrompt({
  name: 'improveIdeaTextPrompt',
  input: {schema: ImproveIdeaTextInputSchema},
  output: {schema: ImproveIdeaTextOutputSchema},
  prompt: `You are an AI assistant that helps improve idea descriptions to be more clear, concise, and engaging.

  Please improve the following idea description:
  {{ideaText}}
  `,
});

const improveIdeaTextFlow = ai.defineFlow(
  {
    name: 'improveIdeaTextFlow',
    inputSchema: ImproveIdeaTextInputSchema,
    outputSchema: ImproveIdeaTextOutputSchema,
  },
  async input => {
    const {output} = await improveIdeaTextPrompt(input);
    return output!;
  }
);
