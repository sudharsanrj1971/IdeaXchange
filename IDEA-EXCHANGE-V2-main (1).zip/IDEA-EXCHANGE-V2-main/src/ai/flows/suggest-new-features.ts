'use server';

/**
 * @fileOverview A flow to suggest new features for an idea using an AI chatbot.
 *
 * - suggestNewFeatures - A function that takes an idea description and returns suggested new features.
 * - SuggestNewFeaturesInput - The input type for the suggestNewFeatures function.
 * - SuggestNewFeaturesOutput - The return type for the suggestNewFeatures function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestNewFeaturesInputSchema = z.object({
  ideaDescription: z
    .string()
    .describe('The description of the idea for which to suggest new features.'),
});
export type SuggestNewFeaturesInput = z.infer<typeof SuggestNewFeaturesInputSchema>;

const SuggestNewFeaturesOutputSchema = z.object({
  suggestedFeatures: z
    .string()
    .describe('A list of suggested new features for the idea.'),
});
export type SuggestNewFeaturesOutput = z.infer<typeof SuggestNewFeaturesOutputSchema>;

export async function suggestNewFeatures(
  input: SuggestNewFeaturesInput
): Promise<SuggestNewFeaturesOutput> {
  return suggestNewFeaturesFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestNewFeaturesPrompt',
  input: {schema: SuggestNewFeaturesInputSchema},
  output: {schema: SuggestNewFeaturesOutputSchema},
  prompt: `You are an AI chatbot designed to suggest new features for ideas.

  Given the following idea description, suggest some new features that could be added to the idea to make it more innovative.

  Idea Description: {{{ideaDescription}}}

  Suggested Features:`,
});

const suggestNewFeaturesFlow = ai.defineFlow(
  {
    name: 'suggestNewFeaturesFlow',
    inputSchema: SuggestNewFeaturesInputSchema,
    outputSchema: SuggestNewFeaturesOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
