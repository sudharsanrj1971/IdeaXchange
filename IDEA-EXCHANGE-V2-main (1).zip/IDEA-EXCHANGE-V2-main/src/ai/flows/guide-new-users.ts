'use server';

/**
 * @fileOverview This file defines a Genkit flow to guide new users through the platform.
 *
 * The flow takes no input and returns a string with instructions on how to use the platform.
 * The `guideNewUsers` function is the entry point for this flow.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GuideNewUsersOutputSchema = z.string().describe('Instructions on how to use the platform.');
export type GuideNewUsersOutput = z.infer<typeof GuideNewUsersOutputSchema>;

export async function guideNewUsers(): Promise<GuideNewUsersOutput> {
  return guideNewUsersFlow({});
}

const prompt = ai.definePrompt({
  name: 'guideNewUsersPrompt',
  output: {schema: GuideNewUsersOutputSchema},
  prompt: `You are a helpful assistant designed to guide new users on the IdeaFlow platform.

  Provide clear and concise instructions on how to:
  1. Submit an idea: Explain the steps to submit a new idea, including filling out the structured fields and saving as a draft or publishing.
  2. Understand versioning: Describe how updating an idea creates a new version and how to access previous versions.
  3. Collaborate: Explain how to contribute to ideas through comments and how usernames and timestamps are logged.
  4. Upvote ideas: Describe how to upvote ideas and how ideas are sorted by votes.
  `,
});

const guideNewUsersFlow = ai.defineFlow(
  {
    name: 'guideNewUsersFlow',
    inputSchema: z.object({}),
    outputSchema: GuideNewUsersOutputSchema,
  },
  async () => {
    const {output} = await prompt({});
    return output!;
  }
);
