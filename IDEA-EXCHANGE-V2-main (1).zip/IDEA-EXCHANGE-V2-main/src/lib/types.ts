export type User = {
  id: string;
  name: string;
  avatarUrl: string;
  bio?: string;
  skills?: string[];
};

export type Comment = {
  id: string;
  author: User;
  content: string;
  createdAt: string;
};

export type IdeaVersion = {
  version: number;
  content: string;
  createdAt: string;
};

export type Idea = {
  id: string;
  title: string;
  shortDescription: string;
  tags: string[];
  author: User;
  upvotes: number;
  createdAt: string;
  updatedAt: string;
  versions: IdeaVersion[];
  comments: Comment[];
  isDraft: boolean;
};
