import type { User, Idea } from '@/lib/types';
import { PlaceHolderImages } from '@/lib/placeholder-images';

const user1: User = {
  id: 'user-1',
  name: 'Alex Doe',
  avatarUrl: PlaceHolderImages.find(img => img.id === 'user-avatar-1')?.imageUrl || '',
  bio: 'Computer Science student passionate about AI and product development.',
  skills: ['React', 'Node.js', 'Python', 'Machine Learning'],
};

const user2: User = {
  id: 'user-2',
  name: 'Jamie Smith',
  avatarUrl: PlaceHolderImages.find(img => img.id === 'user-avatar-2')?.imageUrl || '',
  bio: 'Design student focusing on user experience and sustainable tech.',
  skills: ['UI/UX Design', 'Figma', 'User Research'],
};

const user3: User = {
    id: 'user-3',
    name: 'Taylor Brown',
    avatarUrl: PlaceHolderImages.find(img => img.id === 'user-avatar-3')?.imageUrl || '',
};

export const mockUsers: User[] = [user1, user2, user3];

export const mockIdeas: Idea[] = [
  {
    id: 'idea-1',
    title: 'Campus Sustainability App',
    shortDescription: 'An app to track and promote sustainable practices on campus, rewarding students for eco-friendly actions.',
    tags: ['sustainability', 'mobile-app', 'social-impact'],
    author: user1,
    upvotes: 128,
    createdAt: '2024-05-10T09:00:00Z',
    updatedAt: '2024-05-20T14:30:00Z',
    isDraft: false,
    versions: [
      {
        version: 1,
        content: 'Initial idea submission. Gamify sustainability by allowing students to log actions like recycling, using reusable cups, etc. Points can be redeemed at campus stores.',
        createdAt: '2024-05-10T09:00:00Z',
      },
      {
        version: 2,
        content: 'Updated version. Added a leaderboard feature to foster competition. Also integrated a campus map showing locations of recycling bins and water fountains.',
        createdAt: '2024-05-20T14:30:00Z',
      },
    ],
    comments: [
      {
        id: 'comment-1',
        author: user2,
        content: 'Great idea! We could add a feature to report overflowing bins. From a UX perspective, the onboarding should be really simple.',
        createdAt: '2024-05-11T11:20:00Z',
      },
      {
        id: 'comment-2',
        author: user3,
        content: "What about partnering with local cafes to offer discounts for users who bring their own cups? Could be a good incentive.",
        createdAt: '2024-05-12T16:45:00Z',
      },
    ],
  },
  {
    id: 'idea-2',
    title: 'AI-Powered Study Group Finder',
    shortDescription: 'A platform that uses AI to match students for study groups based on their courses, learning styles, and availability.',
    tags: ['ai', 'education', 'collaboration'],
    author: user2,
    upvotes: 95,
    createdAt: '2024-04-22T18:00:00Z',
    updatedAt: '2024-05-01T10:00:00Z',
    isDraft: false,
    versions: [
        {
            version: 1,
            content: 'A smart platform to connect students. Users input their courses, preferred study times, and take a short quiz to determine their learning style (e.g., visual, auditory). The AI then suggests compatible study groups.',
            createdAt: '2024-04-22T18:00:00Z'
        }
    ],
    comments: [
        {
            id: 'comment-3',
            author: user1,
            content: "The learning style matching is a cool concept. We should consider how to integrate with the university's course registration system to auto-populate classes.",
            createdAt: '2024-04-23T09:15:00Z'
        }
    ]
  },
  {
    id: 'idea-3',
    title: 'AR Campus Tour Guide',
    shortDescription: 'An augmented reality app for new students to explore the campus with interactive information and navigation.',
    tags: ['ar', 'mobile-app', 'university'],
    author: user1,
    upvotes: 72,
    createdAt: '2024-05-15T11:00:00Z',
    updatedAt: '2024-05-15T11:00:00Z',
    isDraft: true,
    versions: [
        {
            version: 1,
            content: 'Initial draft for an AR tour guide. Point your phone at a building and see its name, history, and a list of departments inside. Could also have a "ghost" guide that leads you to your next class.',
            createdAt: '2024-05-15T11:00:00Z'
        }
    ],
    comments: []
  },
  {
    id: 'idea-4',
    title: 'Peer-to-Peer Skill Share Platform',
    shortDescription: 'A marketplace where students can offer and book lessons for skills, from academic tutoring to guitar playing.',
    tags: ['marketplace', 'education', 'community'],
    author: user2,
    upvotes: 210,
    createdAt: '2024-03-10T14:00:00Z',
    updatedAt: '2024-04-15T12:00:00Z',
    isDraft: false,
    versions: [
      {
        version: 1,
        content: 'Initial idea. Students can create a profile listing skills they can teach and their hourly rate (or for free). Other students can browse and book sessions.',
        createdAt: '2024-03-10T14:00:00Z'
      },
      {
        version: 2,
        content: 'Added a rating and review system to build trust. Also implemented a secure messaging and payment system within the platform.',
        createdAt: '2024-04-15T12:00:00Z'
      }
    ],
    comments: [
      {
        id: 'comment-4',
        author: user1,
        content: 'This is brilliant! A "skill swap" feature would be amazing, where students can trade lessons without any money involved.',
        createdAt: '2024-03-12T10:00:00Z'
      }
    ]
  }
];

export const getIdeaById = (id: string) => mockIdeas.find(idea => idea.id === id);
export const getIdeasByAuthor = (userId: string) => mockIdeas.filter(idea => idea.author.id === userId);
export const getContributionsByAuthor = (userId: string) => {
    return mockIdeas.filter(idea => idea.comments.some(comment => comment.author.id === userId));
}
