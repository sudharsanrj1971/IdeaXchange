'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/hooks/use-auth'
import { getIdeasByAuthor, getContributionsByAuthor, mockUsers } from '@/lib/data'
import { IdeaCard } from '@/components/idea-card'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

export default function DashboardPage() {
  const { isAuthenticated } = useAuth()
  const router = useRouter()
  
  // For this mock, we'll assume the logged-in user is user-1
  const currentUser = mockUsers[0]
  const myIdeas = getIdeasByAuthor(currentUser.id)
  const myContributions = getContributionsByAuthor(currentUser.id)

  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (isClient && !isAuthenticated) {
      router.push('/login')
    }
  }, [isAuthenticated, isClient, router])

  if (!isClient || !isAuthenticated) {
    return (
      <div className="container py-12 text-center">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="container max-w-6xl py-12 md:py-16">
      <div className="mb-8">
        <h1 className="text-4xl font-bold tracking-tight font-headline">My Dashboard</h1>
        <p className="mt-2 text-lg text-muted-foreground">Welcome back, {currentUser.name}.</p>
      </div>

      <Tabs defaultValue="ideas" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="ideas">My Ideas</TabsTrigger>
          <TabsTrigger value="contributions">My Contributions</TabsTrigger>
          <TabsTrigger value="profile">My Profile</TabsTrigger>
        </TabsList>
        <TabsContent value="ideas" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>My Ideas</CardTitle>
              <CardDescription>Ideas you have created. You can edit your drafts or create new ideas.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {myIdeas.map(idea => (
                        <IdeaCard key={idea.id} idea={idea} />
                    ))}
                    <Link href="/ideas/new" className="flex items-center justify-center rounded-lg border-2 border-dashed border-muted-foreground/50 text-muted-foreground transition-colors hover:border-primary hover:text-primary">
                        <div className="text-center">
                            <p className="font-semibold text-lg">+</p>
                            <p>Submit a New Idea</p>
                        </div>
                    </Link>
                </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="contributions" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>My Contributions</CardTitle>
              <CardDescription>Ideas you have contributed to through comments.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {myContributions.map(idea => (
                        <IdeaCard key={idea.id} idea={idea} />
                    ))}
                </div>
                 {myContributions.length === 0 && (
                    <div className="text-center py-16">
                        <p className="text-muted-foreground">You haven't contributed to any ideas yet.</p>
                        <Button variant="link" asChild><Link href="/ideas">Explore ideas</Link></Button>
                    </div>
                )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="profile" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>My Profile</CardTitle>
              <CardDescription>Your public profile and information.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-4">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={currentUser.avatarUrl} alt={currentUser.name} />
                  <AvatarFallback>{currentUser.name.slice(0, 2)}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-2xl font-bold">{currentUser.name}</h3>
                  <p className="text-muted-foreground">alex.doe@example.com</p>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Bio</h4>
                <p className="text-muted-foreground">{currentUser.bio}</p>
              </div>
               <div>
                <h4 className="font-semibold mb-2">Skills</h4>
                <div className="flex flex-wrap gap-2">
                    {currentUser.skills?.map(skill => (
                        <Badge key={skill}>{skill}</Badge>
                    ))}
                </div>
              </div>
              <Button variant="outline">Edit Profile</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
