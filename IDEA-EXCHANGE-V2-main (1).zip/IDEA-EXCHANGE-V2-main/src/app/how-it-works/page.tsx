import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Icons } from '@/components/icons';

export default function HowItWorksPage() {
  const steps = [
    {
      icon: Icons.document,
      title: '1. Submit Your Idea',
      description: 'Use our structured submission form to clearly outline your concept. You can save it as a draft to perfect it or publish it directly to the community.',
      imageId: 'how-it-works-submit',
    },
    {
      icon: Icons.team,
      title: '2. Collaborate via Feedback',
      description: 'Other users can view your idea and provide constructive feedback through comments. Every contribution is logged with the contributor\'s name and a timestamp.',
      imageId: 'how-it-works-collab',
    },
    {
      icon: Icons.idea,
      title: '3. Update and Evolve',
      description: 'As your idea improves, you can post updates. Each update creates a new version, building a transparent history of your project\'s evolution that everyone can see.',
      imageId: 'how-it-works-version',
    },
    {
      icon: Icons.vote,
      title: '4. Validate with Votes',
      description: 'The community can upvote ideas they find promising. The most popular ideas rise to the top, gaining more visibility and validation.',
      imageId: 'how-it-works-validate',
    },
  ];

  return (
    <div className="container max-w-5xl py-12 md:py-24">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight font-headline">How IdeaXchange Works</h1>
        <p className="mt-4 text-lg text-muted-foreground">A simple process to bring your ideas to life.</p>
      </div>

      <div className="grid gap-8 md:grid-cols-2">
        {steps.map((step) => {
          const image = PlaceHolderImages.find(p => p.id === step.imageId);
          return (
            <Card key={step.title} className="overflow-hidden">
              {image && (
                 <div className="bg-muted flex items-center justify-center">
                    <Image
                    src={image.imageUrl}
                    alt={image.description}
                    data-ai-hint={image.imageHint}
                    width={400}
                    height={300}
                    className="object-cover w-full h-48"
                    />
                 </div>
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <step.icon className="h-6 w-6 text-primary" />
                  {step.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{step.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
