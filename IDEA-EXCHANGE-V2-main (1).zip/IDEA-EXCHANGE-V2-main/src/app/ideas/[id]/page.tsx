'use client'

import { notFound } from 'next/navigation'
import { getIdeaById } from '@/lib/data'
import type { IdeaVersion, Comment } from '@/lib/types'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowUp, GitBranch, MessageCircle } from 'lucide-react'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { format } from 'date-fns'
import { Separator } from '@/components/ui/separator'
import { Textarea } from '@/components/ui/textarea'

export default function IdeaDetailPage({ params }: { params: { id: string } }) {
  const idea = getIdeaById(params.id)

  if (!idea) {
    notFound()
  }

  return (
    <div className="container max-w-5xl py-12 md:py-16">
      <div className="space-y-4 mb-8">
        <div className="flex flex-wrap gap-2">
          {idea.tags.map((tag) => (
            <Badge key={tag} variant="secondary">{tag}</Badge>
          ))}
        </div>
        <h1 className="text-4xl font-bold tracking-tight font-headline">{idea.title}</h1>
        <div className="flex items-center gap-4 text-muted-foreground">
          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src={idea.author.avatarUrl} alt={idea.author.name} />
              <AvatarFallback>{idea.author.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <span>{idea.author.name}</span>
          </div>
          <span>•</span>
          <span>Created on {format(new Date(idea.createdAt), 'MMM d, yyyy')}</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Idea Overview</TabsTrigger>
              <TabsTrigger value="versions">Version Timeline</TabsTrigger>
              <TabsTrigger value="comments">Contributions</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Current Version (v{idea.versions[idea.versions.length - 1].version})</CardTitle>
                </CardHeader>
                <CardContent className="prose dark:prose-invert max-w-none text-base">
                  <p>{idea.shortDescription}</p>
                  <Separator className="my-4" />
                  <p>{idea.versions[idea.versions.length - 1].content}</p>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="versions" className="mt-6">
              <Card>
                <CardHeader><CardTitle>Version History</CardTitle></CardHeader>
                <CardContent className="space-y-6">
                  {idea.versions.slice().reverse().map((version, index) => (
                    <div key={version.version} className="relative pl-8">
                      <div className="absolute left-0 top-1.5 flex items-center justify-center w-5 h-5 bg-muted rounded-full">
                        <GitBranch className="w-3 h-3 text-muted-foreground" />
                      </div>
                      {index < idea.versions.length -1 && <div className="absolute left-[9px] top-8 h-[calc(100%-1rem)] w-0.5 bg-border" />}
                      <p className="font-semibold">Version {version.version}</p>
                      <p className="text-sm text-muted-foreground">{format(new Date(version.createdAt), 'MMM d, yyyy')}</p>
                      <p className="mt-2 text-sm">{version.content}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="comments" className="mt-6">
              <Card>
                <CardHeader><CardTitle>Community Contributions</CardTitle></CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    {idea.comments.map((comment) => (
                      <div key={comment.id} className="flex gap-4">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={comment.author.avatarUrl} alt={comment.author.name} />
                          <AvatarFallback>{comment.author.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex justify-between items-center">
                            <p className="font-semibold text-sm">{comment.author.name}</p>
                            <p className="text-xs text-muted-foreground">{format(new Date(comment.createdAt), 'MMM d, yyyy')}</p>
                          </div>
                          <p className="text-sm mt-1">{comment.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Separator />
                  <div>
                    <h4 className="font-semibold mb-2">Add your contribution</h4>
                    <Textarea placeholder="Constructive feedback, feature suggestions, questions..." className="mb-2" />
                    <Button>Submit Comment</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <aside className="lg:col-span-1 space-y-6 lg:sticky top-24 self-start">
          <Card>
            <CardContent className="p-4 flex flex-col gap-4">
              <Button size="lg" className="w-full">
                <ArrowUp className="mr-2 h-5 w-5" />
                Upvote ({idea.upvotes})
              </Button>
              <Button variant="outline" size="lg" className="w-full">
                <MessageCircle className="mr-2 h-5 w-5" />
                Contribute
              </Button>
              <Button variant="secondary" size="lg" className="w-full">
                Update Idea
              </Button>
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  )
}
