'use client'

import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { useToast } from '@/hooks/use-toast'

const ideaFormSchema = z.object({
  title: z.string().min(5, {
    message: 'Title must be at least 5 characters.',
  }),
  shortDescription: z.string().min(20, {
    message: 'Short description must be at least 20 characters.',
  }).max(280, {
    message: 'Short description must not be longer than 280 characters.'
  }),
  tags: z.string().min(3, {
    message: 'Please add at least one tag.',
  }),
  content: z.string().min(50, {
    message: 'The main idea content must be at least 50 characters.',
  }),
})

type IdeaFormValues = z.infer<typeof ideaFormSchema>

export default function NewIdeaPage() {
  const router = useRouter()
  const { toast } = useToast()

  const form = useForm<IdeaFormValues>({
    resolver: zodResolver(ideaFormSchema),
    defaultValues: {
      title: '',
      shortDescription: '',
      tags: '',
      content: '',
    },
    mode: 'onChange',
  })

  function onSubmit(data: IdeaFormValues, isDraft: boolean) {
    toast({
      title: 'Idea Submitted!',
      description: `Your idea "${data.title}" has been ${isDraft ? 'saved as a draft' : 'published'}.`,
    })
    // In a real app, you would save the data to a database here.
    // We'll just redirect to the dashboard.
    router.push('/dashboard')
  }

  return (
    <div className="container max-w-3xl py-12 md:py-16">
      <div className="mb-8">
        <h1 className="text-4xl font-bold tracking-tight font-headline">Submit a New Idea</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Bring your concept to life. Fill out the details below to get started.
        </p>
      </div>

      <Form {...form}>
        <form className="space-y-8">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-lg">Idea Title</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., AI-Powered Study Group Finder" {...field} />
                </FormControl>
                <FormDescription>
                  A catchy and descriptive title for your idea.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="shortDescription"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-lg">Short Description</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="A brief summary to capture attention..."
                    className="resize-none"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  This is the elevator pitch for your idea (max 280 characters).
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="tags"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-lg">Tags</FormLabel>
                <FormControl>
                  <Input placeholder="ai, education, mobile-app" {...field} />
                </FormControl>
                <FormDescription>
                  Add comma-separated tags to help others discover your idea.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="content"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-lg">The Core Idea</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Describe your idea in detail. What problem does it solve? Who is it for? How does it work?"
                    className="min-h-[200px]"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  This is where you can elaborate on your concept. Feel free to use Markdown for formatting.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <div className="flex justify-end gap-4">
            <Button variant="outline" onClick={form.handleSubmit((data) => onSubmit(data, true))}>
              Save as Draft
            </Button>
            <Button onClick={form.handleSubmit((data) => onSubmit(data, false))} className="bg-accent hover:bg-accent/90 text-accent-foreground">
              Publish Idea
            </Button>
          </div>
        </form>
      </Form>
    </div>
  )
}
