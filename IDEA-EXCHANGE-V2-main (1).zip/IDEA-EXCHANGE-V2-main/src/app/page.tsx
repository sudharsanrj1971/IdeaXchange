import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Icons } from '@/components/icons';

export default function Home() {
  const heroImage = PlaceHolderImages.find(p => p.id === 'hero-image');

  const problemPoints = [
    { title: 'Ideas Fade Away', description: 'Innovative student ideas often disappear after a hackathon or project showcase ends.' },
    { title: 'No Recognition', description: 'Contributors and original creators lose credit as ideas are informally passed around.' },
    { title: 'Lack of Evolution', description: 'Promising concepts stall without a structured way to gather feedback and iterate.' },
  ];

  const solutionPoints = [
    { icon: Icons.document, title: 'Submit', description: 'Structure your idea and share it with a community ready to engage.' },
    { icon: Icons.team, title: 'Collaborate', description: 'Receive valuable feedback and find collaborators through comments.' },
    { icon: Icons.idea, title: 'Evolve', description: 'Update your idea with new versions, creating a clear timeline of its growth.' },
  ];

  return (
    <div className="flex flex-col items-center">
      {/* Hero Section */}
      <section className="w-full py-20 md:py-32 lg:py-40 bg-card border-b">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:gap-16 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none font-headline">
                Where Student Ideas Evolve
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                From a spark of genius to a fully-fledged concept. IdeaXchange is the platform that gives your ideas the life they deserve after the hackathon ends.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                  <Link href="/ideas/new">Submit Your Idea</Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link href="/ideas">Explore Ideas</Link>
                </Button>
              </div>
            </div>
            {heroImage && (
              <Image
                src={heroImage.imageUrl}
                alt={heroImage.description}
                data-ai-hint={heroImage.imageHint}
                width={1200}
                height={800}
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full"
              />
            )}
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl font-headline">The Post-Hackathon Graveyard</h2>
          <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed mt-4">
            Amazing ideas deserve more than a weekend. We're here to change the narrative.
          </p>
          <div className="mx-auto grid max-w-5xl items-start gap-8 sm:grid-cols-2 md:gap-12 lg:grid-cols-3 mt-12">
            {problemPoints.map((point) => (
              <div key={point.title} className="grid gap-1 text-left p-4 rounded-lg hover:bg-card transition">
                <h3 className="text-lg font-bold">{point.title}</h3>
                <p className="text-sm text-muted-foreground">{point.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-card border-y">
        <div className="container grid items-center justify-center gap-4 px-4 text-center md:px-6">
          <div className="space-y-3">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight font-headline">A Lifecycle for Innovation</h2>
            <p className="mx-auto max-w-[600px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Our platform provides a simple, powerful path for your ideas to grow and gain recognition.
            </p>
          </div>
          <div className="mx-auto grid max-w-5xl items-start gap-8 sm:grid-cols-2 md:gap-12 lg:grid-cols-3 mt-8">
            {solutionPoints.map((point) => (
              <Card key={point.title} className="text-center">
                <CardHeader>
                  <div className="mx-auto bg-primary/10 rounded-full p-3 w-fit">
                    <point.icon className="h-8 w-8 text-primary" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <h3 className="text-lg font-bold">{point.title}</h3>
                  <p className="text-sm text-muted-foreground">{point.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl font-headline">Fostering Student Innovation</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                By giving ideas a home, we empower student creators and build a transparent ecosystem of innovation.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-2 lg:gap-12">
            <div className="flex flex-col justify-center space-y-4">
              <ul className="grid gap-6">
                <li>
                  <div className="grid gap-1">
                    <h3 className="text-xl font-bold">Transparent Credit</h3>
                    <p className="text-muted-foreground">
                      Every contribution is timestamped and attributed, ensuring everyone gets the recognition they deserve.
                    </p>
                  </div>
                </li>
                <li>
                  <div className="grid gap-1">
                    <h3 className="text-xl font-bold">Build Your Portfolio</h3>
                    <p className="text-muted-foreground">
                      Showcase your ideas and contributions as part of your personal portfolio of innovative work.
                    </p>
                  </div>
                </li>
                <li>
                  <div className="grid gap-1">
                    <h3 className="text-xl font-bold">Community-Driven Validation</h3>
                    <p className="text-muted-foreground">
                      Let the community validate your idea through upvotes and constructive feedback.
                    </p>
                  </div>
                </li>
              </ul>
            </div>
            <div className="flex items-center justify-center">
                <Icons.sparkles className="h-48 w-48 text-accent/20" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
