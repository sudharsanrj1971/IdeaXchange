'use server'

import { improveIdeaText, type ImproveIdeaTextInput } from '@/ai/flows/improve-idea-text'
import { guideNewUsers } from '@/ai/flows/guide-new-users'
import { suggestNewFeatures, type SuggestNewFeaturesInput } from '@/ai/flows/suggest-new-features'
import { z } from 'zod'

const improveIdeaSchema = z.object({ ideaText: z.string() })
export async function runImproveIdeaText(input: ImproveIdeaTextInput) {
  const parsed = improveIdeaSchema.parse(input);
  try {
    const result = await improveIdeaText(parsed);
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: "Failed to improve text. The AI assistant may be unavailable." };
  }
}

const suggestFeaturesSchema = z.object({ ideaDescription: z.string() })
export async function runSuggestNewFeatures(input: SuggestNewFeaturesInput) {
  const parsed = suggestFeaturesSchema.parse(input);
  try {
    const result = await suggestNewFeatures(parsed);
    return { success: true, data: result };
  } catch (error) {
      return { success: false, error: "Failed to suggest features. The AI assistant may be unavailable." };
  }
}

export async function runGuideNewUsers() {
    try {
        const result = await guideNewUsers();
        return { success: true, data: result };
    } catch(error) {
        return { success: false, error: "Failed to get guidance. The AI assistant may be unavailable." };
    }
}
