# **App Name**: IdeaFlow

## Core Features:

- Idea Submission: Allow users to submit ideas with structured fields and save them as drafts or publish them.
- Versioning Logic: Implement a system where updating an idea creates a new version, with previous versions remaining read-only.
- Collaboration Logic: Enable collaboration through comments, automatically logging username and timestamp for each contribution.
- Voting Logic: Allow users to upvote ideas, with one vote per user, and sort ideas based on the number of upvotes.
- AI Idea Improver: Integrate the Dudu AI chatbot (with free AI fallback) to suggest improvements to idea text and propose new features; acts as a tool when users request text improvement.
- Explore Ideas Page: Search and filter through idea cards. Each card displays title, description, upvotes and update timestamp.
- User Dashboard: Provides the user access to submitted ideas, contributions, and a link to user profile.

## Style Guidelines:

- Primary color: A muted blue (#74A3C7) to represent innovation and trust.
- Background color: Light gray (#F0F4F7) to provide a clean and student-friendly backdrop.
- Accent color: A vibrant orange (#E58E51) for call-to-action buttons and important highlights to create enthusiasm.
- Body and headline font: 'Inter', a grotesque-style sans-serif providing a modern, neutral look suitable for both headlines and body text.
- Use clean and simple icons to represent different categories of ideas and actions.
- Card-based layout for ideas, contributions, and user profiles, ensuring a structured and easy-to-navigate interface.
- Soft, subtle animations to enhance user experience, such as loading indicators and transitions between pages.